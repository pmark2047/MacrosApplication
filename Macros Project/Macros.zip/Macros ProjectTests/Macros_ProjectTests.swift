//
//  Macros_ProjectTests.swift
//  Macros ProjectTests
//
//  Created by Peyton Markus on 2/18/25.
//

import Testing
@testable import Macros_Project

struct Macros_ProjectTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}

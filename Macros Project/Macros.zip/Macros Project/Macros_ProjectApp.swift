//
//  Macros_ProjectApp.swift
//  Macros Project
//
//  Created by Peyton Markus on 2/18/25.
//

import SwiftUI

@main
struct Macros_ProjectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
